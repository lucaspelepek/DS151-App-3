package com.example.ds151_app3.Detalhes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ds151_app3.R;
import com.example.ds151_app3.model.Team;

public class DetalhesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes2);

        Intent it = getIntent();

        TextView nome = findViewById(R.id.textViewNameTeam);
        TextView cidade = findViewById(R.id.textViewCidadeTeam);
        TextView estado = findViewById(R.id.textViewEstadoTeam);
        TextView historico = findViewById(R.id.textViewHistorico);
        ImageView img = findViewById(R.id.imageViewLogoTeam);

        Team obj = (Team) it.getSerializableExtra("lista");

        nome.setText(obj.getName());
        cidade.setText(obj.getCidade());
        estado.setText(obj.getEstado());
        historico.setText(obj.getHistorico());
        img.setImageResource(obj.getImg());
    }
}