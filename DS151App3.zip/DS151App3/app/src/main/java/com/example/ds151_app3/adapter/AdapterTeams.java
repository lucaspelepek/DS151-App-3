package com.example.ds151_app3.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.example.ds151_app3.R;
import com.example.ds151_app3.model.Team;

import java.util.List;

public class AdapterTeams extends Adapter<AdapterTeams.MyViewHolder> {

    private List<Team> listTeams;
    private OnNoteListener mOnNoteListener;

    public AdapterTeams(List<Team> listTeams, OnNoteListener onNoteListener) {
        this.mOnNoteListener = onNoteListener;
        this.listTeams = listTeams;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View listItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_list_times, parent, false);
        return new AdapterTeams.MyViewHolder(listItem, mOnNoteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Team obj = listTeams.get(position);
        holder.name.setText(obj.getName());
        holder.cidade.setText(obj.getCidade());
        holder.estado.setText(obj.getEstado());
        holder.img.setImageResource(obj.getImg());
    }

    @Override
    public int getItemCount() {
        return listTeams.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView name, cidade, estado;
        ImageView img;
        OnNoteListener onNoteListener;

        public MyViewHolder(View view, OnNoteListener onNoteListener){
            super(view);
            name = view.findViewById(R.id.textViewName);
            cidade = view.findViewById(R.id.textViewOwner);
            estado = view.findViewById(R.id.textViewEstado);
            img = view.findViewById(R.id.imageViewTime);
            this.onNoteListener = onNoteListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onNoteListener.onNoteClick(getAdapterPosition());
        }
    }

    public interface OnNoteListener{
        void onNoteClick(int position);
    }
}
