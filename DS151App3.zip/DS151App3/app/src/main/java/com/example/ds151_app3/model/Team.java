package com.example.ds151_app3.model;

import java.io.Serializable;

public class Team implements Serializable {

    private int img;
    private String name;
    private String cidade;
    private String estado;
    private String historico;

    public Team() {
    }

    public Team(int img, String name, String cidade, String estado, String historico) {
        this.img = img;
        this.name = name;
        this.cidade = cidade;
        this.estado = estado;
        this.historico = historico;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
}
