package com.example.ds151_app3.controller;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ds151_app3.RecyclerItemClickListener;
import com.example.ds151_app3.adapter.AdapterTeams;
import com.example.ds151_app3.R;
import com.example.ds151_app3.model.Team;

import java.util.ArrayList;
import java.util.List;

import com.example.ds151_app3.Detalhes.DetalhesActivity;

public class MainActivity extends AppCompatActivity implements AdapterTeams.OnNoteListener {

    private RecyclerView recyclerViewTimes;
    private List<Team> listTeams = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewTimes = findViewById(R.id.recyclerViewTimes);

        this.createTeam();
        AdapterTeams adapter = new AdapterTeams(listTeams, this);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerViewTimes.setLayoutManager(layoutManager);
        recyclerViewTimes.setHasFixedSize(true);

        recyclerViewTimes.addItemDecoration(new DividerItemDecoration(this, LinearLayout.VERTICAL));

        recyclerViewTimes.setAdapter(adapter);

        recyclerViewTimes.addOnItemTouchListener(new RecyclerItemClickListener(
                getApplicationContext(),
                recyclerViewTimes,
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    }

                    @Override
                    public void onItemClick(View view, int position) {
                        //Intent it = new Intent(this, DetalhesActivity.class);
                        Team obj = listTeams.get(position);
                        Toast.makeText(getApplicationContext(), "Selecionado " + obj.getName(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {
                        Toast.makeText(getApplicationContext(), "Clique longo", Toast.LENGTH_SHORT).show();
                    }
                }
        ));

    }

    private void createTeam() {
        Team obj = new Team(R.drawable.athletico, "Athletico", "Curitiba", "Paraná", "Levain Cup (2019)\nCopa Sul-Americana (2018)\n...");
        listTeams.add(obj);
        obj = new Team(R.drawable.cruzeiro, "Cruzeiro", "Belo Horizonte", "Minas Gerais", "Campeonato Brasileiro (2014)\nCopa do Brasil (2018)\n...");
        listTeams.add(obj);
        obj = new Team(R.drawable.flamengo, "Flamengo", "Rio de Janeiro", "Rio de Janeiro", "Campeonato Brasileiro (2019)\nCopa do Brasil (2013)\n...");
        listTeams.add(obj);
        obj = new Team(R.drawable.santos, "Santos", "Santos", "São Paulo", "Campeonato Paulista (2016)\nRecopa Sudamericana (2012)\n...");
        listTeams.add(obj);
    }

    @Override
    public void onNoteClick(int position) {
        Intent intent = new Intent(this, DetalhesActivity.class);
        intent.putExtra("lista", listTeams.get(position));
        startActivity(intent);
    }
}